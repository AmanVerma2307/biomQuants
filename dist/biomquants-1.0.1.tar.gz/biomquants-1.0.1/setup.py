from setuptools import setup, find_packages
from os import path

working_directory = path.abspath(path.dirname(__file__))

with open(path.join(working_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='biomQuants', # name of packe which will be package dir below project
    version='1.0.1',
    url='https://anonymous.4open.science/r/MeasureSuite-822D',
    author='forteller2307',
    description='An open-source package for biometric quantification: quantifiers and evaluation measures',
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=[],
) 