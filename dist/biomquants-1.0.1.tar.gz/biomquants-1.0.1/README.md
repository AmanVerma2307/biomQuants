<p align="center">
<img src="https://anonymous.4open.science/r/biomQuants-EDEF/assets/biomQuants_Logo_v1.png" width="400" alt="" height="100"/>
</p>

<h1 align="center">biomQuants</h1>

<p align="center">
<img src="https://img.shields.io/badge/Version-1.0.1-blue" alt="version"></a>
<a href="https://anonymous.4open.science/r/biomQuants-EDEF/"><img src="https://img.shields.io/badge/github-repo-yellow?logo=github" alt="github"></a>
<a href="https://anonymous.4open.science/r/MeasureSuite-822D/"><img src="https://img.shields.io/badge/Project-page-green" alt="github"></a>
</p>

### An open source package for biometric quantification: quantifiers and evaluation measures

The package consists of several quantifiers:

1. DGBQA
2. Delta Distance
3. MasterFace
4. Generative Capacity
5. Swipe Quality

We provide several measures:

1. Rank deviation ($\hat{r}$)
2. Relevance ($\mathcal{R}$)
3. Trend match distance ($\Psi$)
4. ICGD Score ($C_d$)
5. Advanced acceptance score (${A_r}^*$)
6. Standard evaluation measures: nDCG, ERR, U, RPP, GRE 

## Requirements

1. numpy
2. sckit-learn
3. scipy
4. tensorflow $\geq$ 2.8.0

## How to use

### Quantifiers
```python
from biomQuants.qauntifers import getScores
scores = getScores(embPath='Path to embeddings',
                    quantifier=quantifier,
                    y_dev=labels,
                    y_dev_id=idLabels,
                    G_total=numCategories,
                    I_total=numIdentities)                    
```
Choice of quantifiers: ['dgbqa','deltaDistance','masterFace','genCapacity','swipeQuality'] 

y_dev: Category labels

y_dev_id: Identity labels

### Evaluation measures
1. Advanced Acceptance Score

```python
from biomQuants.advancedAcceptance import comp_advancedAcceptance
nAr_star = comp_advancedAcceptance(scores,
                                   groundTruth,
                                   embeddings,
                                   labels,
                                   G=numCategories)
```

2. Rank deviation

```python
from biomQuants.rankDev import rankDev
r_prime = rankDev(1-groundTruth,
                  scores,
                  G=numCategories)
```

3. Relevance

```python
import numpy as np
from biomQuants.acceptanceScore import compAr

def preProcess(inputVec):
    inputVec = (inputVec - np.mean(inputVec))/np.std(inputVec)
    return inputVec/np.linalg.norm(inputVec)

relevance = compAr(preProcess(scores),
                   preProcess(groundTruth),
                   normalizer=False,
                   relevance=True)
```

4. ICGD score

```python
import tensorflow as tf
from biomQuants.icgd import compICGD

def normalisation_layer(x):   
    return(tf.math.l2_normalize(x, axis=1, epsilon=1e-12))

embeddings = tf.keras.layers.Lambda(normalisation_layer)(embeddings)

icgdScore = icgdScore(embeddings.numpy(),
                     labels)
```

5. Trend match distance

```python
from biomQuants.trendMatch import compTrendMatchDist
psi = rankDev(scores,
              groundTruth,
              G=numCategories)
```
